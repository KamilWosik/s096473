#!bin/bash
mkdir kopia-home-data-godzina
cd kopia-home-data-godzina
mkdir zad2
cd zad2
mkdir s096473
cd s096473
echo "kopia-home-data-godzina, zad2, s096473">>log.txt